# Foil Studio manuals 0.1.145 (166)

English, Polish, German and Spanish editions, prepared 15 November 2026. These manuals describe this version; check Google Play and https://github.com/plotter-doctor/Foil-Studio/blob/main/docs/release-notes.md for submission and availability. Each language has editable Word, PDF and Markdown text.
