# Foil Studio manuals for 0.1.129 (150)

Edition date: 9 November 2026. These manuals cover the Design, Prepare and Cut
workflow, layers and their materials, production jobs, active project recovery,
imports, non-destructive plotter preparation, the 30 x 30 mm calibration grid, Print & Cut and supported plotter workflows.

[Download all four languages](FoilStudio-Manual-All-Languages.zip)

| Language | Printable PDF | Editable Word | Text edition |
| --- | --- | --- | --- |
| English | [PDF](FoilStudio-Manual-en.pdf) | [Word](FoilStudio-Manual-en.docx) | [Text](FoilStudio-Manual-en.md) |
| Polski | [PDF](FoilStudio-Manual-pl.pdf) | [Word](FoilStudio-Manual-pl.docx) | [Tekst](FoilStudio-Manual-pl.md) |
| Deutsch | [PDF](FoilStudio-Manual-de.pdf) | [Word](FoilStudio-Manual-de.docx) | [Text](FoilStudio-Manual-de.md) |
| Español | [PDF](FoilStudio-Manual-es.pdf) | [Word](FoilStudio-Manual-es.docx) | [Texto](FoilStudio-Manual-es.md) |

The four editions cover the same topics. Their page counts differ because the
translated text reflows. Example names identify editable projects in the app's
Help section. Keep your own saved projects and exported backups.

This edition describes version 0.1.129 (150). See the
[Foil Studio documentation](https://github.com/plotter-doctor/Foil-Studio)
for current release and Google Play availability. Earlier dated manuals remain
historical editions.
